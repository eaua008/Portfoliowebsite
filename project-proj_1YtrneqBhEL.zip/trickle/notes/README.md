# Developer Portfolio Website

## Overview
A multi-page developer portfolio website featuring:
- **Home Page**: Introduction and about section
- **Projects Page**: List of all projects
- **Project Detail Page**: Detailed view with tabbed interface for:
  - Source Code (editable IDE)
  - Pseudocode
  - Diagram

## Technology Stack
- React 18
- TailwindCSS
- Trickle Database
- Lucide Icons

## Pages Structure
- `index.html` - Homepage with hero and about sections
- `projects.html` - Projects listing page
- `project-detail.html` - Individual project detail with tabs

## Database Schema
### ObjectType: project
- `name`: Project name
- `description`: Project description
- `sourceCode`: Editable source code
- `pseudocode`: Project pseudocode
- `diagramUrl`: URL to project diagram image

## Features
- Responsive design
- Editable source code (owner only)
- Tab navigation for different code views
- Database-backed project storage