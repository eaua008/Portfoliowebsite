When project is updated
- Check if README.md in trickle/notes needs updates
- Update README.md if:
  - New pages or features are added
  - Database schema changes
  - Major functionality changes
  - New components or structure changes
- Keep README concise and up-to-date