function About() {
  try {
    return (
      <section id="about" className="py-20 bg-[var(--bg-dark)]" data-name="about" data-file="components/About.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 style={{"paddingTop":"0px","paddingRight":"0px","paddingBottom":"0px","paddingLeft":"0px","marginTop":"0px","marginRight":"0px","marginBottom":"16px","marginLeft":"350px","fontSize":"36px","color":"rgb(248, 250, 252)","backgroundColor":"rgba(0, 0, 0, 0)","textAlign":"center","fontWeight":"700","objectFit":"fill","display":"block","position":"static","top":"auto","left":"auto","right":"auto","bottom":"auto"}} className="text-4xl font-bold text-[var(--text-primary)] mb-4">About Me</h2>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">Hi! I'm Eijkim Maulit, a passionate BS Computer Science student at Mapúa Malayan Colleges Mindanao specializing in mobile and web application development. I enjoy transforming ideas into practical and user-friendly solutions through code, with experience in C#, HTML, CSS, Java, and JavaScript. I'm driven by curiosity and creativity, always eager to learn new technologies, take on challenges, and build software that makes a meaningful impact.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-lg border border-purple-800 bg-[var(--bg-darker)] hover:shadow-lg hover:shadow-purple-500/20 transition">
              <div className="w-16 h-16 mx-auto mb-4 bg-purple-900 rounded-lg flex items-center justify-center">
                <div className="icon-code text-2xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[var(--text-primary)]">Clean Code</h3>
              <p className="text-[var(--text-secondary)]">
                Writing maintainable and efficient code following best practices
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg border border-cyan-800 bg-[var(--bg-darker)] hover:shadow-lg hover:shadow-cyan-500/20 transition">
              <div className="w-16 h-16 mx-auto mb-4 bg-cyan-900 rounded-lg flex items-center justify-center">
                <div className="icon-lightbulb text-2xl text-[var(--secondary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[var(--text-primary)]">Innovation</h3>
              <p className="text-[var(--text-secondary)]">
                Exploring new technologies and creative solutions to problems
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg border border-purple-800 bg-[var(--bg-darker)] hover:shadow-lg hover:shadow-purple-500/20 transition">
              <div className="w-16 h-16 mx-auto mb-4 bg-purple-900 rounded-lg flex items-center justify-center">
                <div className="icon-target text-2xl text-[var(--primary-color)]"></div>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-[var(--text-primary)]">Goal Oriented</h3>
              <p className="text-[var(--text-secondary)]">
                Focused on delivering results that exceed expectations
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('About component error:', error);
    return null;
  }
}
