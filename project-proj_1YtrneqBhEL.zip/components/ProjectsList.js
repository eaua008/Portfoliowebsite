function ProjectsList() {
  try {
    const [projects, setProjects] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadProjects();
    }, []);

    const loadProjects = async () => {
      try {
        const result = await trickleListObjects('project', 100, true);
        setProjects(result.items);
      } catch (error) {
        console.error('Failed to load projects:', error);
      } finally {
        setLoading(false);
      }
    };

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-xl text-[var(--text-secondary)]">Loading projects...</div>
        </div>
      );
    }

    return (
      <section className="py-20 bg-[var(--bg-dark)]" data-name="projects-list" data-file="components/ProjectsList.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-[var(--text-primary)] mb-12">My Projects</h1>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map(project => (
              <a
                key={project.objectId}
                href={`project-detail.html?id=${project.objectId}`}
                className="bg-[var(--bg-darker)] rounded-lg p-6 border border-purple-800 hover:shadow-lg hover:shadow-purple-500/30 transition"
              >
                <h3 className="text-xl font-semibold mb-2">{project.objectData.name}</h3>
                <p className="text-[var(--text-secondary)] mb-4">{project.objectData.description}</p>
                <div className="text-[var(--primary-color)] font-medium flex items-center">
                  View Details
                  <div className="icon-arrow-right text-sm ml-2"></div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('ProjectsList component error:', error);
    return null;
  }
}