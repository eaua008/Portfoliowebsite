function Hero() {
  try {
    return (
      <section className="relative bg-gradient-to-br from-[var(--bg-darker)] via-purple-950 to-[var(--bg-dark)] py-20 overflow-hidden" data-name="hero" data-file="components/Hero.js">
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{backgroundImage: 'url(https://app.trickle.so/storage/public/images/usr_17023b3f60000001/0451abfb-3831-4674-ac20-5cb4c5e606c7.jpeg)'}}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold text-[var(--text-primary)] mb-6">Hello, I'm Eijkim 
</h1>
              <p className="text-xl text-[var(--text-secondary)] mb-8">
                Building innovative solutions and crafting elegant code for the future
              </p>
              <div className="flex space-x-4">
                <a 
                  href="projects.html" 
                  className="px-8 py-3 bg-[var(--primary-color)] text-white rounded-lg hover:opacity-90 transition shadow-lg shadow-purple-500/50"
                >
                  View Projects
                </a>
                <a 
                  href="#about" 
                  className="px-8 py-3 border-2 border-[var(--secondary-color)] text-[var(--secondary-color)] rounded-lg hover:bg-[var(--secondary-color)] hover:text-white transition"
                >
                  Learn More
                </a>
              </div>
            </div>
            
            <div className="flex justify-center mt-2.5">
              <div className="w-80 h-80 rounded-full bg-gradient-to-br from-purple-600 to-cyan-500 p-1 shadow-2xl shadow-purple-500/50">
                <img 
                  src="https://app.trickle.so/storage/public/images/usr_17023b3f60000001/3b454a03-0550-4cee-bbe7-00aecb54fde6.jpeg" 
                  alt="Developer Photo" 
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}
