function ProjectDetail() {
  try {
    const [project, setProject] = React.useState(null);
    const [activeTab, setActiveTab] = React.useState('source');
    const [sourceCode, setSourceCode] = React.useState('');
    const [isEditing, setIsEditing] = React.useState(false);

    React.useEffect(() => {
      const params = new URLSearchParams(window.location.search);
      const projectId = params.get('id');
      if (projectId) {
        loadProject(projectId);
      }
    }, []);

    const loadProject = async (projectId) => {
      try {
        const projectData = await trickleGetObject('project', projectId);
        setProject(projectData);
        setSourceCode(projectData.objectData.sourceCode || '// Add your source code here');
      } catch (error) {
        console.error('Failed to load project:', error);
      }
    };

    const saveSourceCode = async () => {
      try {
        await trickleUpdateObject('project', project.objectId, {
          ...project.objectData,
          sourceCode: sourceCode
        });
        setIsEditing(false);
        alert('Source code saved successfully!');
      } catch (error) {
        console.error('Failed to save source code:', error);
        alert('Failed to save source code');
      }
    };

    if (!project) {
      return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
    }

    return (
      <div className="py-20 bg-[var(--bg-dark)]" data-name="project-detail" data-file="components/ProjectDetail.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-4 text-[var(--text-primary)]">{project.objectData.name}</h1>
          <p className="text-lg text-[var(--text-secondary)] mb-8">{project.objectData.description}</p>
          
          <div className="bg-[var(--bg-darker)] rounded-lg shadow-sm border border-purple-800">
            <div className="border-b border-purple-800 flex">
              <button
                onClick={() => setActiveTab('source')}
                className={`px-6 py-4 font-medium ${activeTab === 'source' ? 'border-b-2 border-[var(--primary-color)] text-[var(--primary-color)]' : 'text-[var(--text-secondary)]'}`}
              >
                Source Code
              </button>
              <button
                onClick={() => setActiveTab('pseudo')}
                className={`px-6 py-4 font-medium ${activeTab === 'pseudo' ? 'border-b-2 border-[var(--primary-color)] text-[var(--primary-color)]' : 'text-[var(--text-secondary)]'}`}
              >
                Pseudocode
              </button>
              <button
                onClick={() => setActiveTab('diagram')}
                className={`px-6 py-4 font-medium ${activeTab === 'diagram' ? 'border-b-2 border-[var(--primary-color)] text-[var(--primary-color)]' : 'text-[var(--text-secondary)]'}`}
              >
                Diagram
              </button>
            </div>
            
            <div className="p-6">
              {activeTab === 'source' && (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Source Code Editor</h3>
                    {isEditing ? (
                      <div className="space-x-2">
                        <button onClick={saveSourceCode} className="px-4 py-2 bg-[var(--primary-color)] text-white rounded">
                          Save
                        </button>
                        <button onClick={() => setIsEditing(false)} className="px-4 py-2 border border-gray-300 rounded">
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button onClick={() => setIsEditing(true)} className="px-4 py-2 bg-[var(--primary-color)] text-white rounded">
                        Edit
                      </button>
                    )}
                  </div>
                  <textarea
                    value={sourceCode}
                    onChange={(e) => setSourceCode(e.target.value)}
                    disabled={!isEditing}
                    className="w-full h-96 p-4 font-mono text-sm border border-purple-700 rounded bg-[var(--bg-dark)] text-[var(--text-primary)]"
                  />
                </div>
              )}
              
              {activeTab === 'pseudo' && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">Pseudocode</h3>
                  <pre className="bg-[var(--bg-dark)] p-4 rounded border border-purple-700 whitespace-pre-wrap text-[var(--text-primary)]">
                    {project.objectData.pseudocode || 'No pseudocode available'}
                  </pre>
                </div>
              )}
              
              {activeTab === 'diagram' && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">Diagram</h3>
                  <div className="bg-[var(--bg-dark)] p-8 rounded border border-purple-700 text-center">
                    {project.objectData.diagramUrl ? (
                      <img src={project.objectData.diagramUrl} alt="Project Diagram" className="max-w-full mx-auto" />
                    ) : (
                      <p className="text-[var(--text-secondary)]">No diagram available</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProjectDetail component error:', error);
    return null;
  }
}