function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    
    return (
      <header className="bg-[var(--bg-darker)] border-b border-purple-900 sticky top-0 z-50 backdrop-blur-sm bg-opacity-90" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <a href="index.html" className="text-2xl font-bold text-[var(--primary-color)]">
              Developer Portfolio
            </a>
            
            <nav className="hidden md:flex space-x-8">
              <a href="index.html" className="text-[var(--text-primary)] hover:text-[var(--primary-color)] transition">
                Home
              </a>
              <a href="projects.html" className="text-[var(--text-primary)] hover:text-[var(--primary-color)] transition">
                Projects
              </a>
            </nav>
            
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div className="icon-menu text-xl text-[var(--text-primary)]"></div>
            </button>
          </div>
          
          {isMenuOpen && (
            <div className="md:hidden py-4 space-y-2">
              <a href="index.html" className="block py-2 text-[var(--text-primary)] hover:text-[var(--primary-color)]">
                Home
              </a>
              <a href="projects.html" className="block py-2 text-[var(--text-primary)] hover:text-[var(--primary-color)]">
                Projects
              </a>
            </div>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}